import bpy

# ==============================================================================
# 0. 共用核心邏輯 (Core 版：相容 Blender 4.x / 5.0+，純粹提取 Blender 內的貼圖連線數據)
# ==============================================================================

def extract_material_data_shared(obj):
    """
    分析指定物件的材質節點，並回傳其貼圖通道的對應關係。
    Core 版本移除引擎橋接座標轉換，專注於材質結構分析。
    """
    if not obj.data.materials or not obj.data.materials[0]:
        return None, "沒有找到材質"

    mat = obj.data.materials[0]
    if not mat.use_nodes:
        return None, f"材質 '{mat.name}' 未使用節點"

    node_tree = mat.node_tree
    bsdf_node = next((n for n in node_tree.nodes if n.type == 'BSDF_PRINCIPLED'), None)
    output_node = next((n for n in node_tree.nodes if n.type == 'OUTPUT_MATERIAL'), None)
    
    if not bsdf_node:
        return None, "材質中沒有 Principled BSDF 節點"

    # Core 版：移除 Transform (座標轉換) 邏輯，僅保留基礎識別資訊與貼圖對應
    data = {
        "MaterialName": mat.name,
        "MeshName": obj.name,
        "TextureMapping": {}
    }
    
    target_inputs = {
        'Base Color': 'BaseColor',
        'Normal': 'Normal',
        # [PAID_ONLY_REMOVED_IN_DEMO]
    }
    
    for bsdf_input_name, channel_key in target_inputs.items():
        if bsdf_input_name not in bsdf_node.inputs:
            continue

        input_socket = bsdf_node.inputs[bsdf_input_name]
        
        if input_socket.links:
            link = input_socket.links[0]
            source_node = link.from_node
            tex_node = None
            
            if channel_key == 'Normal' and source_node.type == 'NORMAL_MAP':
                if source_node.inputs['Color'].links:
                    tex_node = source_node.inputs['Color'].links[0].from_node
            
            # 🔥 修正：相容 Blender 4.0/5.0+ 的 Mix 節點 (MIX_RGB 變更為 MIX)
            elif channel_key == 'BaseColor' and source_node.type in ['MIX_RGB', 'MIX']:
                # 5.0 的 Mix 節點插槽是 'A' 和 'B'，舊版則是索引 1 和 2
                input_a = source_node.inputs.get('A') if 'A' in source_node.inputs else source_node.inputs[1]
                input_b = source_node.inputs.get('B') if 'B' in source_node.inputs else source_node.inputs[2]
                
                node1 = next((l.from_node for l in input_a.links if l.from_node.type == 'TEX_IMAGE'), None)
                node2 = next((l.from_node for l in input_b.links if l.from_node.type == 'TEX_IMAGE'), None)
                
                tex_node = node1 if node1 else node2
                
                # [PAID_ONLY_REMOVED_IN_DEMO]
            elif source_node.type == 'TEX_IMAGE':
                tex_node = source_node
            
            if tex_node and tex_node.type == 'TEX_IMAGE' and tex_node.image:
                data["TextureMapping"][channel_key] = {
                    "Path": bpy.path.abspath(tex_node.image.filepath),
                    "SourceNodeName": tex_node.name,
                    "ColorSpace": tex_node.image.colorspace_settings.name,
                    "Channel": None
                }
    
    # [PAID_ONLY_REMOVED_IN_DEMO]

    # [PAID_ONLY_REMOVED_IN_DEMO]
    
    return data, None
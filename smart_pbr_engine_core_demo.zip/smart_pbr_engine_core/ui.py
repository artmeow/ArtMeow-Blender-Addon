import bpy
from bpy.types import UIList, Panel
from .properties import T  # 匯入聰明翻譯函式

# ==============================================================================
# 0. UI 列表渲染類別 (同步 MAX 版本視覺效果)
# ==============================================================================

# [PAID_ONLY_REMOVED_IN_DEMO]

class SMART_PBR_UL_ChannelList(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row()
        row.label(text=f"{item.channel_name}", icon='IMAGE_DATA')
        row.label(
            text=f"{T('lbl_total')} {item.count} {T('lbl_pics')}",
            icon='CHECKMARK' if item.count > 0 else 'ERROR'
        )

# ==============================================================================
# 1. 主面板 (S1 ~ S4)
# ==============================================================================

class SMART_PBR_PT_MainPanel(Panel):
    bl_label = "Smart PBR Engine" 
    bl_idname = "SMART_PBR_PT_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "SPE Core"  # Core 基礎版專屬標籤

    def draw(self, context):
        layout = self.layout
        props = context.scene.smart_pbr_settings
        
        # 語系切換
        layout.prop(props, "ui_lang", expand=True)
        layout.separator()
        
        # [PAID_ONLY_REMOVED_IN_DEMO]
            
        if props.mode == "CHANNEL":
            box = layout.box()
            box.label(text=T("folder_title_channel"))
            box.prop(props, "texture_dir", text=T("texture_dir"))
            
        # S2 - 通道關鍵字設定
        box = layout.box()
        box.label(text=T("s2_title"))
        from . import IS_DEMO
        for i, cs in enumerate(props.channel_settings):
            if IS_DEMO and cs.channel_type not in ('BaseColor', 'Normal'):
                continue
            row = box.row(align=True)
            row.prop(cs, "channel_type", text=f"{T('lbl_channel')}{i+1}")
            row.prop(cs, "keywords", text=T("lbl_keyword"))
            
        # S3 - 智能 Shader 建立
        box = layout.box()
        box.label(text=T("s4_title"))
        box.prop(props, "shader_prefix", text=T("shader_prefix"))
        box.prop(props, "main_texture_name", text=T("main_texture_name"))
        box.operator("smart_pbr.create_smart_shader_multimode", icon="NODE_MATERIAL", text=T("btn_shader"))
        
        layout.separator()
        layout.operator("smart_pbr.match_batch", icon='FILE_REFRESH', text=T("btn_match"))
        
        # S4 - 配對結果顯示
        box = layout.box()
        # [PAID_ONLY_REMOVED_IN_DEMO]
        if props.mode == "CHANNEL":
            box.label(text=T("result_channel"))
            layout.template_list("SMART_PBR_UL_ChannelList", "", props, "channel_items", props, "channel_items_index", rows=9)

# ==============================================================================
# 2. 註冊與註銷 (完全移除 EngineBridge 面板)
# ==============================================================================

classes = (
    # [PAID_ONLY_REMOVED_IN_DEMO]
    SMART_PBR_UL_ChannelList,
    SMART_PBR_PT_MainPanel,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
IS_DEMO = True

bl_info = {
    "name": "Smart PBR Engine Core", 
    "author": "Art Meow",
    "version": (4, 0, 1),
    "blender": (4, 2, 0),
    "description": "Auto PBR setup",
    "tracker_url": "https://senja.io/p/our-community-voice/r/yaV6eB",
    "doc_url": "https://artmeow.framer.website/",
    "category": "Material",
}

import bpy
from . import properties
from . import operators
from . import ui

modules = [
    properties,
    operators,
    ui,
]

# ==============================================================================
# 安全的初始化機制 (同步 MAX 版本邏輯)
# ==============================================================================
@bpy.app.handlers.persistent
def load_handler(dummy):
    """當開啟新檔案或載入完成後，安全地初始化預設通道"""
    if hasattr(bpy.context, "scene") and hasattr(bpy.context.scene, "smart_pbr_settings"):
        properties.ensure_default_channels(bpy.context.scene.smart_pbr_settings)

def init_timer():
    """用來在剛安裝/打勾啟用 Addon 的當下，延遲 0.1 秒執行初始化"""
    load_handler(None)
    return None  # 回傳 None 代表只執行一次就關閉計時器

# ==============================================================================
# 註冊與卸載
# ==============================================================================
def register():
    # 1. 註冊所有模組
    for mod in modules:
        mod.register()
    
    # 2. 綁定 Scene 屬性
    bpy.types.Scene.smart_pbr_settings = bpy.props.PointerProperty(type=properties.SmartPBRSettings)
    
    # 3. 註冊事件：確保未來每次開啟 Blender 檔案都會檢查並補齊通道
    if load_handler not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(load_handler)
        
    # 4. 註冊計時器：延遲 0.1 秒後再寫入資料，避免 RestrictContext 錯誤
    bpy.app.timers.register(init_timer, first_interval=0.1)

def unregister():
    # 移除事件監聽
    if load_handler in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(load_handler)
        
    for mod in reversed(modules):
        mod.unregister()
        
    del bpy.types.Scene.smart_pbr_settings

if __name__ == "__main__":
    register()
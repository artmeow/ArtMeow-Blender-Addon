import bpy
import os
import re
from bpy.types import Operator

# ==============================================================================
# 0. 列表管理操作符 (Core 版)
# ==============================================================================

# [PAID_ONLY_REMOVED_IN_DEMO]

# ==============================================================================
# 1. 配對與智能 Shader 建立邏輯 (同步 MAX 版本 - 相容 Blender 5.0+)
# ==============================================================================

class SMART_PBR_OT_MatchBatch(Operator):
    bl_idname = "smart_pbr.match_batch"
    bl_label = "執行批次配對"
    bl_description = "依目前所選模式進行批次配對"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.smart_pbr_settings
        # [PAID_ONLY_REMOVED_IN_DEMO]
        if props.mode == "CHANNEL":
            props.update_channel_matches(context)
            self.report({'INFO'}, "通道批次分類已完成")
        return {'FINISHED'}

class SMART_PBR_OT_CreateSmartShader_MultiMode(bpy.types.Operator):
    bl_idname = "smart_pbr.create_smart_shader_multimode"
    bl_label = "一鍵批次建立Shader（Mesh名稱全自動配對）"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.smart_pbr_settings
        prefix = props.shader_prefix.strip() or "M_"
        channel_map = props.get_channel_map()
        texture_dir = bpy.path.abspath(props.texture_dir)
        all_files_map = {}
        for root, _, files in os.walk(texture_dir):
            for f in files:
                lower_basename = os.path.basename(f).lower()
                all_files_map[lower_basename] = os.path.join(root, f)

        selected_objs = [obj for obj in context.selected_objects if obj.type == "MESH"]
        if not selected_objs:
            self.report({'WARNING'}, "請先選取要自動建立Shader的物件")
            return {'CANCELLED'}

        from . import IS_DEMO
        main_names_empty = True if IS_DEMO else not (props.main_names.strip())
        main_texture_name = props.main_texture_name.strip().lower()
        result_msgs = []

        def shader_workflow(obj, tex_per_channel, mat_name):
            mat = bpy.data.materials.get(mat_name)
            if not mat:
                mat = bpy.data.materials.new(mat_name)
            mat.use_nodes = True
            node_tree = mat.node_tree
            nodes = node_tree.nodes
            links = node_tree.links
            for node in nodes:
                nodes.remove(node)
            output_node = nodes.new("ShaderNodeOutputMaterial")
            output_node.location = (400, 0)
            bsdf_node = nodes.new("ShaderNodeBsdfPrincipled")
            bsdf_node.location = (0, 0)
            links.new(bsdf_node.outputs['BSDF'], output_node.inputs['Surface'])
            channel_shader_map = {
                "BaseColor": "Base Color",
                "Normal": "Normal",
                # [PAID_ONLY_REMOVED_IN_DEMO]
            }
            tex_y = 0
            ao_mix_node = None
            ao_from_mrao = None
            basecolor_tex_node = None

            # [PAID_ONLY_REMOVED_IN_DEMO]

            for ch, shader_input in channel_shader_map.items():
                # [PAID_ONLY_REMOVED_IN_DEMO]
                tex_path = tex_per_channel.get(ch)
                if tex_path and os.path.isfile(tex_path):
                    tex_node = nodes.new("ShaderNodeTexImage")
                    tex_node.label = ch
                    tex_node.location = (-400, tex_y)
                    try:
                        tex_node.image = bpy.data.images.load(tex_path, check_existing=True)
                    except Exception as e:
                        continue
                    if ch in ["Normal"]:
                        tex_node.image.colorspace_settings.name = 'Non-Color'
                    # [PAID_ONLY_REMOVED_IN_DEMO]

                    if ch == "BaseColor":
                        basecolor_tex_node = tex_node
                    elif ch == "Normal":
                        norm_node = nodes.new("ShaderNodeNormalMap")
                        norm_node.location = (-200, tex_y)
                        links.new(tex_node.outputs['Color'], norm_node.inputs['Color'])
                        links.new(norm_node.outputs['Normal'], bsdf_node.inputs['Normal'])
                    # [PAID_ONLY_REMOVED_IN_DEMO]
                    
                    tex_y -= 250

            if basecolor_tex_node:
                links.new(basecolor_tex_node.outputs['Color'], bsdf_node.inputs['Base Color'])

            # [PAID_ONLY_REMOVED_IN_DEMO]

            if obj.data.materials:
                obj.data.materials[0] = mat
            else:
                obj.data.materials.append(mat)

        if main_names_empty:
            for obj in selected_objs:
                mesh_name = obj.name.lower()
                mat_name = f"{prefix}{mesh_name}" if not main_texture_name else f"{prefix}{main_texture_name}"
                tex_per_channel = {}
                for channel, keywords in channel_map.items():
                    tex_per_channel[channel] = None
                    for lower_basename, full_path in all_files_map.items():
                        if lower_basename.startswith(mesh_name):
                            for kw in keywords:
                                pattern = f"{mesh_name}_{kw.lower()}"
                                if pattern in lower_basename:
                                    tex_per_channel[channel] = full_path
                                    break
                        if tex_per_channel[channel]:
                            break
                shader_workflow(obj, tex_per_channel, mat_name)
                result_msgs.append(f"[{obj.name}] 全自動配對完成")
        # [PAID_ONLY_REMOVED_IN_DEMO]

        self.report({'INFO'}, "； ".join(result_msgs))
        return {'FINISHED'}


# ==============================================================================
# 2. 註冊與註銷 (不含匯出引擎工具)
# ==============================================================================

classes = (
    # [PAID_ONLY_REMOVED_IN_DEMO]
    SMART_PBR_OT_MatchBatch,
    SMART_PBR_OT_CreateSmartShader_MultiMode,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
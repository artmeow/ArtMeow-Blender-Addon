import bpy
import os
import re
from bpy.props import StringProperty, CollectionProperty, IntProperty, EnumProperty, PointerProperty
from bpy.types import PropertyGroup

# ==============================================================================
# 0. 語系字典與翻譯函式 (I18N - 一處修改，全端生效 - Core 版本專屬)
# ==============================================================================
STRINGS = {
    'ZH': {
        "panel_title": "Smart PBR Mapper (Core)",
        "mode_name": "主名稱批次配對",
        "mode_channel": "通道貼圖數據工具",
        "s1_title": "📂 S1 - 主名稱 / 資料夾",
        "s2_title": "🔍 S2 - 通道設定（下拉選單+關鍵字）",
        "s4_title": "⚡ S3 - 智能 Shader 建立",
        "mesh_main_map": "🔗 Mesh ↔ 主名稱對應表（優先匹配）",
        "btn_add_map": "新增一組 Mesh-主名稱",
        "btn_rm_map": "移除一組 Mesh-主名稱",
        "btn_shader": "一鍵批次建立Shader",
        "btn_match": "執行批次配對",
        "result_name": "📦 S4 - 主名稱批次配對結果",
        "result_channel": "📦 S4 - 通道分類配對結果",
        "folder_title_channel": "📂 S1 - 通道分類 / 指定資料夾",
        "texture_dir": "貼圖資料夾",
        "main_names_list": "主名稱清單",
        "shader_prefix": "Shader 命名前綴",
        "main_texture_name": "貼圖主名稱 (選填)",
        "lbl_main_name": "主名稱",
        "lbl_total": "共",
        "lbl_pics": "張",
        "lbl_channel": "通道",
        "lbl_keyword": "關鍵字",
    },
    'EN': {
        "panel_title": "Smart PBR Mapper (Core)",
        "mode_name": "Name Batch Match",
        "mode_channel": "Channel Data Tool",
        "s1_title": "📂 S1 - Main Name / Folder",
        "s2_title": "🔍 S2 - Channel Keywords Setup",
        "s4_title": "⚡ S3 - Smart Shader Creation",
        "mesh_main_map": "🔗 Mesh ↔ Main Name Map (Priority)",
        "btn_add_map": "Add Map Entry",
        "btn_rm_map": "Remove Map Entry",
        "btn_shader": "One-Click Create Shaders",
        "btn_match": "Execute Batch Match",
        "result_name": "📦 S4 - Name Batch Match Results",
        "result_channel": "📦 S4 - Channel Classification Results",
        "folder_title_channel": "📂 S1 - Channel Mode / Target Folder",
        "texture_dir": "Texture Folder",
        "main_names_list": "Main Names List",
        "shader_prefix": "Shader Prefix",
        "main_texture_name": "Main Texture Name (Optional)",
        "lbl_main_name": "Main Name",
        "lbl_total": "Total",
        "lbl_pics": "Pics",
        "lbl_channel": "Channel ",      
        "lbl_keyword": "Keywords",  
    }
}

def T(key):
    """全局翻譯輔助函式：給定 key，回傳對應語系的字串"""
    try:
        lang = bpy.context.scene.smart_pbr_settings.ui_lang
    except AttributeError:
        lang = 'ZH' # 預設中文
    return STRINGS.get(lang, STRINGS['ZH']).get(key, key)

# ==============================================================================
# 1. 核心資料結構與屬性
# ==============================================================================
# [PAID_ONLY_REMOVED_IN_DEMO]

class SmartPBRChannelSetting(PropertyGroup):
    channel_type: EnumProperty(
        name="通道",
        description="Select the PBR channel type.",
        items=[
            ('BaseColor', "BaseColor", "Albedo or Base Color map."),
            ('Normal', "Normal", "Normal map."),
            # [PAID_ONLY_REMOVED_IN_DEMO]
        ],
        default='BaseColor'
    )
    keywords: StringProperty(
        name="關鍵字",
        description="Keywords to match this channel (separated by commas)."
    )

# [PAID_ONLY_REMOVED_IN_DEMO]

class SmartPBRChannelItem(PropertyGroup):
    channel_name: StringProperty(description="Channel name.")
    files: StringProperty(description="Matched files.")
    count: IntProperty(description="Number of matched files.")

class SmartPBRSettings(PropertyGroup):
    # UI 語系切換開關
    ui_lang: EnumProperty(
        name="Language / 語言",
        description="Switch the UI language.",
        items=[
            ('ZH', "繁體中文", "Use Traditional Chinese Interface"),
            ('EN', "English", "Use English Interface")
        ],
        default='ZH'
    )
    
    mode: EnumProperty(
        name="批次模式",
        description="Select the batch operation mode.",
        items=[
            # [PAID_ONLY_REMOVED_IN_DEMO]
            ("CHANNEL", "通道貼圖數據工具", "Scan directory by channel keywords."),
        ],
        default="CHANNEL"
    )
    texture_dir: StringProperty(
        name="貼圖資料夾",
        description="Specify the target folder containing texture files.",
        subtype='DIR_PATH'
    )
    # [PAID_ONLY_REMOVED_IN_DEMO]
    channel_settings: CollectionProperty(type=SmartPBRChannelSetting)
    channel_settings_index: IntProperty(default=0)
    shader_prefix: StringProperty(
        name="Shader命名前綴",
        description="Prefix for the generated shader material names.",
        default="M_"
    )
    main_texture_name: StringProperty(
        name="貼圖主名稱 (選填)",
        description="Optional main texture name to force matching.",
        default=""
    )
    # [PAID_ONLY_REMOVED_IN_DEMO]
    channel_items: CollectionProperty(type=SmartPBRChannelItem)
    channel_items_index: IntProperty(default=0)
    # [PAID_ONLY_REMOVED_IN_DEMO]
    
    # Core 版：已移除 ue_export_path 與 unity_export_path

    def get_channel_map(self):
        from . import IS_DEMO
        if IS_DEMO:
            return {cs.channel_type: [k.strip().lower() for k in cs.keywords.split(",") if k.strip()] for cs in self.channel_settings if cs.channel_type in ('BaseColor', 'Normal')}
        return {cs.channel_type: [k.strip().lower() for k in cs.keywords.split(",") if k.strip()] for cs in self.channel_settings}

    # [PAID_ONLY_REMOVED_IN_DEMO]

    def update_channel_matches(self, context):
        self.channel_items.clear()
        folder = bpy.path.abspath(self.texture_dir)
        if not os.path.isdir(folder):
            return

        channel_map = self.get_channel_map()
        results = {k: [] for k in channel_map.keys()}
        all_files = []
        for root, _, files in os.walk(folder):
            all_files += [os.path.join(root, f) for f in files]
        for file in all_files:
            fname = os.path.basename(file).lower()
            for channel, keywords in channel_map.items():
                for kw in keywords:
                    if kw in fname:
                        results[channel].append(os.path.basename(file))
        for channel in channel_map.keys():
            item = self.channel_items.add()
            item.channel_name = channel
            item.files = ",".join(results[channel])
            item.count = len(results[channel])

def ensure_default_channels(props):
    from . import IS_DEMO
    if IS_DEMO:
        if len(props.channel_settings) == 0:
            ch1 = props.channel_settings.add()
            ch1.channel_type = 'BaseColor'
            ch1.keywords = ""
            ch2 = props.channel_settings.add()
            ch2.channel_type = 'Normal'
            ch2.keywords = ""
        elif len(props.channel_settings) == 1:
            ch2 = props.channel_settings.add()
            ch2.channel_type = 'Normal'
            ch2.keywords = ""
        elif len(props.channel_settings) > 2:
            while len(props.channel_settings) > 2:
                props.channel_settings.remove(len(props.channel_settings) - 1)
        return

    # [PAID_ONLY_REMOVED_IN_DEMO]

classes = (
    # [PAID_ONLY_REMOVED_IN_DEMO]
    SmartPBRChannelSetting,
    # [PAID_ONLY_REMOVED_IN_DEMO]
    SmartPBRChannelItem,
    SmartPBRSettings,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)